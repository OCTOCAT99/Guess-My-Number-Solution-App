import random
number = random.randint(1, 10)

player_name = input("Hello, What's your name?")
number_of_guesses = 0
print("Okay " + player_name + ", I am Guessing a number between 1 and 10:")

while number_of_guesses < 5:
    guess = int(input("What is your guess? "))
    number_of_guesses += 1
    if guess < number:
        print("Your guess is too low")
    elif guess > number:
        print("Your guess is too high")
    else:
        break
if guess == number:
    print("Congratulations! You guessed correctly.")
else:
    print("You did not guess the number, The number was ")
    print(number)